package com.yash.springorm;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springorm.dao.StudentDao;
import com.yash.springorm.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
		//Student stu = new Student(4, "Amit");
		//int msg = studao.insert(stu);
		//System.out.println(msg + "insertion done");
		//int msg=studao.getStudentDetails(2);
		List<Student> stu = studao.getAllStudents();
		for (Student s : stu) {
			System.out.println(s);
		}
		//Student msg=studao.getStudentDetails(2);
		//System.out.println(msg);
		//studao.deleteDetails(3);
		//System.out.println("Deletion Done");
		//studao.updateDetails(stu);
		//System.out.println("Updation Done");
		
		
	}
}