interface Drawable
{
	public void draw();
}
public class WithoutLambdaExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int w=10;
		Drawable d=new Drawable() {
			
			@Override
			public void draw() {
				// TODO Auto-generated method stub
				System.out.println("Drwaing-"+w);
			}
		};
		d.draw();
	}

}
