package springconsref;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App {

	public static void main(String[] args) {
		System.out.println("second spring using refrence");
		ApplicationContext context=new ClassPathXmlApplicationContext("springconsref/applicationcontext.xml");
		A e=(A)context.getBean("refa");
		System.out.println(e);
		}
	

}
