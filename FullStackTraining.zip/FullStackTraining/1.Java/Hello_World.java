package java_fun;
class Hello_world
{
 public static void main(String[] args) 
{
//String str="Hello";
System.out.println("Hello World");
}
}

