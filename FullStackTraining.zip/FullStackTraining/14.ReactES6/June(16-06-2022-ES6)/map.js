const marksStu = new Map([["anil",67],["sunil",87]]);

console.log(marksStu.get("anil"));
marksStu.set("sanjay",77);
marksStu.set("sumit",87);
marksStu.set("jay",70);
marksStu.set("vijay",71);

marksStu.forEach(function(value,key){
	console.log("key:-"+key +" value:- "+value);	
});
marksStu.delete("anil");

console.log("after deleting anil");
marksStu.forEach(function(value,key){
	console.log("key:-"+key +" value:- "+value);	
});

if(marksStu.has("anil"))
	 console.log("anil exist");
 else
	 console.log("anil does not exist");
for(let t of marksStu.entries())
{
	// when we fetch values using entries funciton it return array of key and value, key is at 0 index and value is at 1 index 
	console.log(t[0]+t[1]);	
}	