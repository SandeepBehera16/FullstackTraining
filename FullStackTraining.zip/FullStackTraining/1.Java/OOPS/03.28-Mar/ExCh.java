//package mypack;
import java.io.FileInputStream;
class ExCh
{
	public static void main(String[] args)
	{
	try
	{
	FileInputStream f=new FileInputStream("D:/xyz.txt");
	System.out.println("Hello");
	}
	catch(Exception e)
	{
	System.out.println(e);
	}
	System.out.println("Bye");
	}
}