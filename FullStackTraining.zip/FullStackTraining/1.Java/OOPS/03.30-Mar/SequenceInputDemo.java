import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;
class ByteArrayInputDemo
{
public static void main(String[] args) throws Exception
{
FileInputStream f1=new FileInputStream("d:/abc.txt");
FileOutputStream ot=new FileOutputStream("d:/def.txt");
ByteArrayInputStream byt = new ByteArrayInputStream(f1);  
int i;
while((i=byt.read())!=-1)
{
ot.write(i);
}
st.close();
ot.close();
f1.close();
f2.close();
}
}