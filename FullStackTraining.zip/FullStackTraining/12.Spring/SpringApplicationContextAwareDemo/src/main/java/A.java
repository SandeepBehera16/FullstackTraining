
public class A {
	public void doTask(){
		System.out.println("I am in class A");
	}
}
