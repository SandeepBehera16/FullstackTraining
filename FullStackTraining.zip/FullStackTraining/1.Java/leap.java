import java.util.Scanner;
class leap
{
public static void main(String[] args)
{
  int n;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter a Year:");
  n=sc.nextInt();
  if((n%4==0 && n%100!=0) || (n%400==0))
        System.out.println(n+" is a Leap year.");
  else
        System.out.println(n+" is not a Leap year.");
}
} 
