package springmvc.controller;

public class Employee {
	private String name;
	private String emalid;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String name, String emalid) {
		super();
		this.name = name;
		this.emalid = emalid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmalid() {
		return emalid;
	}
	public void setEmalid(String emalid) {
		this.emalid = emalid;
	}
	

}
