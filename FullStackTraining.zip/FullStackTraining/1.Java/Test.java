public class Test {
	public static void main(String[] args)
		throws ClassNotFoundException
	{
		Class c1 = Class.forName("java.lang.String");
		Object c2=new String("AlphaBitaGamma");
		Class a =c2.getClass();
		Class b=Test.class;
		/*System.out.println("Class represented by c1: "+ c1.toString());
		System.out.println("Class represented by c2: "+ c2.toString());

		System.out.print("Class represented by c3: "+ b.toString());*/
		System.out.println(c1.isArray());
		System.out.println(c1.isPrimitive());
		Class c3=int.class;
		System.out.println(c3.isPrimitive());		
	}
}
