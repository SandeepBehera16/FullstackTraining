import java.util.Scanner;
class rev
{
public static void main(String[] args)
{
        int i,n,r=0,rev=0;
        System.out.println("Enter a number");
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();i=n;
        while(n>0)
        {
		r=n%10;
	        rev=rev*10+r;
                n=n/10;
        }
        System.out.println("Reverse of  "+i+" : "+rev);
}
}
