import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ContactList
{
	HashMap<String, Integer> contacts=new HashMap<>();
	public void addContacts(String name,Integer number)
	{
		contacts.put(name, number);
	}
	public void removeContacts(String name)
	{
		contacts.remove(name);
	}
	public String toString()
	{
		return "ContactList [contacts="+contacts+"]";
	}
	public boolean doesContactNameExists(String name)
	{
		Set<Entry<String,Integer>> set=contacts.entrySet();
		Iterator<Entry<String,Integer>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, Integer> me=i.next();
			if(me.getKey().equals(name))
				return true;
		}
		return false;
	}
	public boolean doesContacNumbertExists(Integer number)
	{
		Set<Entry<String,Integer>> set=contacts.entrySet();
		Iterator<Entry<String,Integer>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, Integer> me=i.next();
			if(me.getValue().intValue()==(number))
				return true;
		}
		return false;
	}
	public void ListAllContacts()
	{
		Set<Entry<String,Integer>> set=contacts.entrySet();
		Iterator<Entry<String,Integer>> i=set.iterator();
		while(i.hasNext())
		{
			Map.Entry<String, Integer> me=i.next();
			System.out.println(me);
		}	
	}
	
}
class AssinQ3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactList c=new ContactList();
		c.addContacts("Sandeep", 987654321);
		c.addContacts("Deepak", 987654433);
		c.addContacts("Ambulence", 108);
		System.out.println("Ambulence:"+c.doesContactNameExists("Ambulence"));
		System.out.println("987654321:"+c.doesContacNumbertExists(987654321));
		System.out.println("\n");
		c.ListAllContacts();
	}

}
