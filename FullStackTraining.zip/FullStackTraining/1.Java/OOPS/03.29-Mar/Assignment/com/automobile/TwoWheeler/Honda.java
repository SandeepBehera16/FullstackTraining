package com.automobile.twoWheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle
{
public int getSpeed()
{
return 200;
}
public void cdPlayer()
{
System.out.println("CD player");
}
public String getModelName()
{
return "Honda";
}
public String getRegistrationnumber()
{
return "MP2342";
}
public String getOwnerName()
{
return "Sandeep Behera";
}
}