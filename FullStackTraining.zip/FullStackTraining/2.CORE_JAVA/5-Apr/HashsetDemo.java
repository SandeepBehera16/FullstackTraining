import java.util.HashSet;
import java.util.Iterator;
public class HashsetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				HashSet<String> a=new HashSet<String>();
				a.add("Sergio");
				a.add("Lisbon");
				a.add("Tokyo");
				a.add("Berlin");
				a.add("Nairobi");
				System.out.println(a);
				Iterator i=a.iterator();
				while(i.hasNext())
				{
					System.out.println(i.next());
				}
						
			}

		}