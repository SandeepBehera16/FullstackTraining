class MyThread1 extends Thread
{
	public void run()
	{
		System.out.println("I am in thread 1");
	}
}
class MyThread2 extends Thread
{
	public void run()
	{
		System.out.println("I am in thread 2");
	}
}
class MyThread3 extends Thread
{
	public void run()
	{
		System.out.println("I am in thread 3");
	}
}


public class ThreadDemo3Multi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread1 td1=new MyThread1();
		td1.start();
		MyThread2 td2=new MyThread2();
		td2.start();
		MyThread3 td3=new MyThread3();
		td3.start();
	}

}
