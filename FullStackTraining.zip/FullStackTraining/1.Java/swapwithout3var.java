import java.util.Scanner;
class swapwithout3var
{
public static void main(String[] args)
{
  int a,b,t;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter 2 numbers:");
  a=sc.nextInt();
  b=sc.nextInt();
        System.out.println("Before Swapping numbers are: "+a+","+b);
  t=a;
  a=b;
  b=t;
        System.out.println("After Swapping numbers are: "+a+","+b);
}
}
