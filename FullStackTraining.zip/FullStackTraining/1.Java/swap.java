import java.util.Scanner;
class swap
{
public static void main(String[] args)
{
  int a,b;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter 2 numbers:");
  a=sc.nextInt();
  b=sc.nextInt();
	System.out.println("Before Swapping numbers are: "+a+","+b);
  a=a+b;
  b=a-b;
  a=a-b;
        System.out.println("After Swapping numbers are: "+a+","+b);
}
}
