class Outer{
	void disp(){
		System.out.println("Outside of inner class");
	}
	class Inner{
		void show(){
			System.out.println("Outer Show");
		}
	}
}
public class ODemoStatic{
	public static void main(String[] args){
		Outer o=new Outer();
		//o.disp();
		Outer.Inner oi=o.new Inner(); I
		oi.show();
	}
}