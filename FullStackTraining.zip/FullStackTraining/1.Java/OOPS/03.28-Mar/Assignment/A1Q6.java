import java.util.Scanner;
class Neg extends RuntimeException
{
	Neg(String s)
	{ super(s);
	}
}
class Gtr100 extends RuntimeException
{
	Gtr100(String s)
	{ super(s);
	}
}
class A1Q6
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<=2;i++)
	{
	double s1=0,s2=0,s3=0;
	try
	{
		
	        System.out.println("Enter the marks:");
		s1=sc.nextDouble();
		if(s1<0.00) throw new Neg("Marks below 0!!...Error");
		if(s1>100.00) throw new Gtr100("Marks above 100!!..Error");
		s2=sc.nextDouble();
		if(s2<0.00) throw new Neg("Marks below 0!!...Error");
		if(s2>100.00) throw new Gtr100("Marks above 100!!..Error");
		s3=sc.nextDouble();
		if(s3<0.00) throw new Neg("Marks below 0!!...Error");
		if(s3>100.00) throw new Gtr100("Marks above 100!!..Error");
	}
	catch(Neg e)
	{e.printStackTrace();}
	catch(Gtr100 e)
	{e.printStackTrace();}
	System.out.println("Marks of Student "+(i+1)+":");
	System.out.println("Marks of subject 1: " + s1);
	System.out.println("Marks of subject 2: " + s2);
	System.out.println("Marks of subject 3: " + s3);
	}
		
	sc.close();

	}

}