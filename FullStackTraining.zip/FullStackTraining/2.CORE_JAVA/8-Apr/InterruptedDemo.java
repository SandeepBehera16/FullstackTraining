
public class InterruptedDemo extends Thread {
	public void run()
	{
		//System.out.println(Thread.interrupted());
		//System.out.println(Thread.interrupted());
		System.out.println(Thread.currentThread().isInterrupted());
		System.out.println(Thread.currentThread().isInterrupted());
		for(int i=1;i<=3;i++)
		{
			try
			{
				System.out.println(i);
				Thread.sleep(2000);
				//System.out.println(Thread.interrupted());
				//System.out.println(Thread.currentThread().isInterrupted());

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterruptedDemo t=new InterruptedDemo();
		t.start();
		t.setName("Thread-1");
		t.interrupt();
		//t.interrupt();
		InterruptedDemo t1=new InterruptedDemo();
		t1.start();
		t.setName("Thread-2");
		t1.interrupt();
		//t1.interrupt();
	}

}
