

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class AssignmentQ3{

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader f=new FileReader("d:/yash.txt");
		BufferedReader br=new BufferedReader(f);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character to count in the file");
		char ch=sc.next().charAt(0);
		   int count=0;
        String currentLine = br.readLine();
         
        while (currentLine != null)
        {
           
            String[] words = currentLine.split(" ");
          
            for (String word : words)
            {
            	  System.out.println(word);
            	String s1=word;
            	for(int j=0;j<s1.length();j++)
            	{
            		char ch1=s1.charAt(j);
            		if(ch1==ch)
            		{
            			count++;
            		}
            		
            	}
            	
            }
       
            currentLine = br.readLine();
        }
        System.out.println(ch+" Occurs "+count+"times in the file");
	}

}
