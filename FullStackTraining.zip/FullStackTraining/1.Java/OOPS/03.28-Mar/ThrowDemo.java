import java.util.Scanner;
class VoteElg extends RuntimeException
{
	VoteElg(String s)
	{	super(s);
	}
}
class ThrowDemo
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your age:");
	int age=sc.nextInt();
	try
	{
		if(age<18)
			throw new VoteElg("You are not eligible to vote");
		else
			System.out.println("You can vote");
	}
	catch(VoteElg e)
	{
		e.printStackTrace();
	}
	System.out.println("Normal Termination");
}
}