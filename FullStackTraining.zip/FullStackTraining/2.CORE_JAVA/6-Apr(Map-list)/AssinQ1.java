import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class AssinQ1 {

	public static void main(String[] args) {
		Map<String,String> map=new HashMap<>();
		map.put("Odisha", "Bhubaneswar");
		map.put("Westbengal", "Kolkata");
		map.put("Karnataka","Banglore");
		Set<Entry<String,String>> set=map.entrySet();
		Iterator<Entry<String,String>> it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry<String, String> me=it.next();
			if(me.getKey().equals("Westbengal"))
			{
				System.out.println("Key Westbengal exists");
				break;
			}
		}
		set=map.entrySet();
		it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry<String, String> me=it.next();
			if(me.getValue().equals("Banglore"))
			{
				System.out.println("Value Karnataka exists");
				break;
			}		
		}
		set=map.entrySet();
		it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry<String, String> me=it.next();
				System.out.println(me);
				
		}	
		

	}

}
