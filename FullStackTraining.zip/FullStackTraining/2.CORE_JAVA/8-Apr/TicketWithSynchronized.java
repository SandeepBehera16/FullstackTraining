class BookTicket
{
	static int totalseats=12;
	static synchronized void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats-=seats;
			System.out.println("Remaining seates: "+totalseats);
		}
		else
			System.out.println("Seats are not avaliable. Only "+totalseats+" are avaliable.");
	}
}
class Thread1 extends Thread
{
	static BookTicket b;
	int seats;
	Thread1(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run()
	{
		b.bookSeat(seats);
	}
}class Thread2 extends Thread
{
	static BookTicket b;
	int seats;
	Thread2(BookTicket b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run()
	{
		b.bookSeat(seats);
	}
}
public class TicketWithSynchronized extends Thread{
	/*static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookTicket b=new BookTicket();
		Thread1 t1= new Thread1(b, 8);
		t1.start();
		Thread2 t2=new Thread2(b, 3);
		t2.start();
		BookTicket b1=new BookTicket();
		Thread1 t3= new Thread1(b1, 8);
		t3.start();
		Thread2 t4=new Thread2(b1, 3);
		t4.start();
		/*b=new BookTicket();
		TicketWithSynchronized p1=new TicketWithSynchronized();
		p1.seats=8;
		p1.start();
		TicketWithSynchronized p2=new TicketWithSynchronized();
		p2.seats=10;
		p2.start();*/
	}

}
