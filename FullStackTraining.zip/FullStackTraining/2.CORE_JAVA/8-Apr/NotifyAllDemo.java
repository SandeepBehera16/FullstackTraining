class Thread01 extends Thread
{
	public void run()
	{
		synchronized (this) 
		{
			System.out.println(Thread.currentThread().getState());
			System.out.println(Thread.currentThread().getName());
			try
			{
				this.wait();
				System.out.println("Am waiting main Thread");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
}
class Thread02 extends Thread
{
	Thread01 t1;
	Thread02(Thread01 t1)
	{
		this.t1=t1;
	}
	public void run()
	{
		synchronized (this.t1) 
		{
			System.out.println(t1.getState());
			System.out.println(Thread.currentThread().getName());
			try
			{
				this.t1.wait();
				System.out.println("Am waiting-Thread2");

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
	}
}
class Thread03 extends Thread
{
	Thread01 t1;
	public Thread03(Thread01 t1) {
		this.t1=t1;
	}
	public void run()
	{
		synchronized (this.t1) 
		{
			System.out.println(t1.getState());
			System.out.println(Thread.currentThread().getName());
			try {
				this.t1.notifyAll();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}
public class NotifyAllDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Thread01 th1=new Thread01();
		Thread t1=new Thread(th1,"Thread-1");
		t1.start();
		
		Thread02 th2=new Thread02(th1);
		Thread t2=new Thread(th2,"Thread-2");
		t2.start();
		
		Thread03 th3=new Thread03(th1);
		Thread t3=new Thread(th3,"Thread-3");
		Thread.sleep(100);
		t3.start();		

	}

}
