package testpackage;

public class Foundation {
	private int Var1;
	int Var2;
	protected int Var3;
	public int Var4;
}