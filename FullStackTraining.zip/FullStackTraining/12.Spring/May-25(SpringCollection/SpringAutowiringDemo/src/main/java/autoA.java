public class autoA {

	autow1 obj;

	autoA() {
		System.out.println(" autoA  is created");
	}

	public autow1 getautow1() {

		return obj;

	}

	public void setAutow1(autow1 obj) {

		this.obj = obj;

	}

	void print() {
		System.out.println("hello autoA");
	}

	void display() {

		print();

		obj.print();

	}
}