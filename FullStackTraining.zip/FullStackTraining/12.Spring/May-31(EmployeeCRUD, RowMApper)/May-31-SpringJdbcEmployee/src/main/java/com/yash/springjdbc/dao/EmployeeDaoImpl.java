package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.*;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbctemp;

	public int insert(Employee emp) {

		String q = "insert into employee(id,name,emailid,dob,contactno,salary) values(?,?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getId(), emp.getName(), emp.getEmailid(), emp.getDob(), emp.getContactno(), emp.getSalary());
		return msg;
	}
	

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	public int updatedetails(Employee emp) {
		// update details of student
		String q="update employee set name=? where id=?";
		int msg=this.jdbctemp.update(q,emp.getName(),emp.getId());

		return msg;
		}
	public int deletedetails(int empid) {
		// TODO Auto-generated method stub
		String q="delete from employee where id=?";
		int msg=this.jdbctemp.update(q,empid);

		return msg;

		}
}