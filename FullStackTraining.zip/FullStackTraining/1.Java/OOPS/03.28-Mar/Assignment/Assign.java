import java.util.Scanner;
public class Assign {  
           
   public static void main(String[] args) {  
	String str ;
	int n=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a string:");
	str=sc.nextLine();
        try {  
                 n= Integer.parseInt(str);  
        }catch(NumberFormatException ex){  
            System.out.println("Entered input is not in valid format for an integer");  
            
        }  
	int sq=n*n;
	System.out.println("Square of "+n+" = "+sq);
            }  
}  