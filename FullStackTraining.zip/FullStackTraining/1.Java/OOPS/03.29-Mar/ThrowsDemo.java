import java.io.FileNotFoundException;
import java.io.FileInputStream;
class ThrowsD
{
void show() throws FileNotFoundException 
{
FileInputStream f=new FileInputStream("d:/Yash.txt");
}
}
class ThrowsDemo
{ public static void main(String[] args)
{ ThrowsD t=new ThrowsD();
   try{
	t.show();}
   catch(FileNotFoundException e)
	{e.printStackTrace();}
    System.out.println("Normal Termination");
}
}