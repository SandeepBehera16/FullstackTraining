import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternAssignmentQ4 {
	public static void main(String[] args) {
		String s="score score and score years ago our fathers...";
		Pattern p=Pattern.compile(" (\\S*or\\S*) ");
		Matcher m=p.matcher(s);
		if(m.find())
		{
			String g=m.group(1);
			System.out.format("'%s'\n",g);
		}
	}

}
