package springStudentaap;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class mainAap {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println("Welcome to Spring Frist Application");
	ApplicationContext context= new ClassPathXmlApplicationContext("applicationcontext.xml");
	Student s=(Student) context.getBean("student");
	System.out.println(s);
	
	}
}
