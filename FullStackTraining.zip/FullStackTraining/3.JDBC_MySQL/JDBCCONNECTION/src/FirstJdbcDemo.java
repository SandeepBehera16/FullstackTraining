import java.sql.*;
class FirstJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
				//step 1:load the driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				//step 2:create connection
				String url="jdbc:mysql://localhost:3306/sandeep";
				String user="root";
				String pass="24may1980";
				Connection con=DriverManager.getConnection(url,user,pass);
				if(con!=null)
				{
					System.out.println("Connection is created");
				}
				else
					System.out.println("Connection is not created");
				//step 3:create query
				String q="select * from employee";
				Statement st=con.createStatement();
				ResultSet set=st.executeQuery(q);
				//step 4:process the data
				while(set.next())
				{
					int id=set.getInt("empID");//(1)
					String name=set.getString("name");
					System.out.print("Id:"+id);
					System.out.print(" Name:"+name+"\n");
				}	
				//step 5: connection close
				con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}	