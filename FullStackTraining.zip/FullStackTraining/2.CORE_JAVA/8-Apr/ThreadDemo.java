
public class ThreadDemo extends Thread {
	public void run()
	{
		System.out.println("Thread Started");
		System.out.println(Thread.currentThread().getState());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo t=new ThreadDemo();
		t.start();
	}

}
