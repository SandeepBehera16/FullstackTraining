import java.util.HashSet;
import java.util.Iterator;
class Country
{
	HashSet<String> h1=new HashSet<>();
	public HashSet<String> saveCountryNames(String CountryName)
	{
		h1.add(CountryName);
		return h1;
	}
	public String getCountry(String CountryName)
	{
		Iterator<String> i=h1.iterator();
		while(i.hasNext())
		{
			if(i.next().equals(CountryName))
				return CountryName;
		}
		return null;
	}
}
class AssignmentQ5Country
{
	public static void main(String[]args){	
		Country c=new Country();
		c.saveCountryNames("India");
		c.saveCountryNames("China");
		c.saveCountryNames("Bhutan");
		c.saveCountryNames("Nepal");
		c.saveCountryNames("America");
		System.out.println("India: "+c.getCountry("India"));
		System.out.println("Nepal: "+c.getCountry("Nepal"));
	}
}	