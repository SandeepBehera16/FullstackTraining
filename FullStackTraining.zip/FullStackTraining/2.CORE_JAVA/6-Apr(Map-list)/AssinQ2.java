import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class AssinQ2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties p=new Properties();
		p.setProperty("Odisha", "Bhubaneswar");
		p.setProperty("Westbengal", "Kolkata");
		p.setProperty("Karnataka", "Banglore");
		Set<Entry<Object, Object>> set=p.entrySet();
		Iterator<Entry<Object,Object>> i=set.iterator();
		while(i.hasNext())
		{
			Entry<Object,Object> e=i.next();
			System.out.println(e);
		}
	}

}
