import java.io.FileInputStream;
import java.io.*;
import java.io.IOException;
class AssignmentQ2
{
	public static void main(String[] args) throws IOException
	{
        File file = new File("d:/yash.txt");
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        BufferedReader f1 = new BufferedReader(inputStreamReader);
	int line;
        int count = 0,c1=0,c2=0,c3=0,c4=0,c5=0;
        while((line=f1.read())!=-1)
        {
	
                switch(line)
        {
            case 'a':c1++; break;
            case 'e':c2++; break;
            case 'i':c3++;break;
            case 'o':c4++;break;
            case 'u':c5++;break;
            case 'A':c1++;break;
            case 'E':c2++;break;
            case 'I':c3++;break;
            case 'O':c4++;break;
            case 'U':c5++;
		       
        }
	}
        System.out.println("Total number of vowels= "+(c1+c2+c3+c4+c5));
	System.out.println("Number of 'a' = " + c1);
		System.out.println("Number of 'e' = " + c2);
		System.out.println("Number of 'i' = " + c3);
		System.out.println("Number of 'o' = " + c4);
		System.out.println("Number of 'u' = " + c5);

        f1.close();
	}
}