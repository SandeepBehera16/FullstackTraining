package lifecycleOfbean;

public class Animal {

  private String name;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void show() {
    System.out.println("Name of the Animal is : " + name);
  }

  public void init() {
    System.out.println("<----------Init method is called---------->");
  }

  public void destroy() {
    System.out.println("<----------Destroy method is called------------>");
  }

}
