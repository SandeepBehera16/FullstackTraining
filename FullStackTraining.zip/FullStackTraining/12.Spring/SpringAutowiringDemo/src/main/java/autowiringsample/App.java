package autowiringsample;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import AnnotationsInAutowire.Employee;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("autowiringsample/applicationcontext.xml");
		Employee e = context.getBean("emp", Employee.class);
		//BeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("autowiringsample/applicationcontext.xml"));
		//Employee e = context.getBean("emp", Employee.class);

		//Employee e = (Employee) beanFactory.getBean("empi");
		System.out.println(e);

	}

}
