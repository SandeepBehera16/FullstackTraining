package ResourceAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			System.out.println("Welcome to Spring Annotation with Resource Application");
			ApplicationContext context= new ClassPathXmlApplicationContext("ResourceAnnotation/applicationcontext.xml");

			Employee emp = context.getBean("emp", Employee.class);
			System.out.println(emp.toString());
			
	}

}

