import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobileCheckUsingRegex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Moble Number:");
		String mobile=sc.nextLine();
		if(isValidNumber(mobile))
			System.out.println("Numer is valid.");
		else
			System.out.println("Number is invalid!!");
		System.out.println("Enter Email ID");
		String email=sc.nextLine();
		if(isValidEmail(email))
			System.out.println("Email is valid.");
		else
			System.out.println("Email is invalid!!");
		System.out.println("Enter Url:");
		String url=sc.nextLine();
		if(isValidUrl(url))
			System.out.println("URL is valid.");
		else
			System.out.println("URL is invalid!!");
		
	}
	public static boolean isValidNumber(String mo)
	{
		Pattern p=Pattern.compile("^\\d{10}$");
		Matcher m=p.matcher(mo);
		return (m.matches());
	}
	public static boolean isValidEmail(String e)
	{
		Pattern p=Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
		Matcher m=p.matcher(e);
		return (m.matches());
	}
	public static boolean isValidUrl(String u)
	{
		Pattern p=Pattern.compile(" \"((http|https)://)(www.)?\"\r\n"
				+ "              + \"[a-zA-Z0-9@:%._\\\\+~#?&//=]\"\r\n"
				+ "              + \"{2,256}\\\\.[a-z]\"\r\n"
				+ "              + \"{2,6}\\\\b([-a-zA-Z0-9@:%\"\r\n"
				+ "              + \"._\\\\+~#?&//=]*)\"");
		Matcher m=p.matcher(u);
		return (m.matches());
	}
	

}
