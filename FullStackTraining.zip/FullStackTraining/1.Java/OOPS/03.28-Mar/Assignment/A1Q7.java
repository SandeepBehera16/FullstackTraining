import java.util.Scanner;
class Invalidcountry extends Exception{
public Invalidcountry(String s)
{super(s);
}}
class A1Q7{
public static void main(String[] args)
{
	String name,ctry;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Name:");
	name=sc.nextLine();
	System.out.println("Enter Country:");
	ctry=sc.nextLine();
	try{
	if(!ctry.equals("India")) throw new Invalidcountry("Invalid country exception!!..Country other than INDIA cannot be taken");
	else
		System.out.println("User Registration done.");
	}
	catch(Invalidcountry e)
	{e.printStackTrace();}
}
}
	