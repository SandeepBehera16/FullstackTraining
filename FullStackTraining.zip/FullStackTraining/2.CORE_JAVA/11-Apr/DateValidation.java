import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> dt=new ArrayList<String>();
		dt.add("2/2/22");
		dt.add("9/1/22");
		dt.add("22/9/22");
		dt.add("12/12/22");
		dt.add("Abcdefg");
		Pattern p=Pattern.compile("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$");
		for(String d: dt)
		{
			Matcher m=p.matcher(d);
			System.out.println(d+":"+m.matches());
		}

	}

}
