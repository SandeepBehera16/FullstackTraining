function countVowels(str) {
  const vowels = str.match(/[aeiou]/gi).length; 
  const consonants = str.match(/[^aeiou]/gi).length; 
	console.log('Number of vowels: '+vowels);
	console.log('Number of consonants: '+consonants);
 
};
const str = 'monster is coming' ;

const value = countVowels(str);

