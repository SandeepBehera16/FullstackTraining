package com.yash.springjdbc;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao = context.getBean("StudentDao", StudentDao.class);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username: ");
		String uname=sc.nextLine();
		System.out.println("Enter Password: ");
		String pass=sc.nextLine();
		int ch=0;
		if(pass.equals("yash"))
		{
			do
			{
				System.out.println("Wellcome to CRUD Application ");
				System.out.println("1.Read all");
				System.out.println("2.Insert");
				System.out.println("3.Update");
				System.out.println("4.Delete");
				System.out.println("5.Exit");
				System.out.println("Choose your Option:");
				ch=sc.nextInt();
				switch(ch)
				{
				case 1:
						List<Student> stu = stdao.getAllDetails();
						for (Student s : stu) {
							System.out.println(s);
						}
						break;
				case 2:	
						Student s = new Student();
						s.setId(106);
						s.setName("Ram Kumar");
						int r = stdao.insert(s);
						System.out.println(r + " Student added Successfully ");
						break;
				case 3: 
						Student s1 = new Student();
						s1.setId(105);
						s1.setName("Chitra Mathur");
						int r1=stdao.updatedetails(s1);
						System.out.println(r1 + " Student details Updated Successfully ");
						break;
				case 4:
						System.out.println("Enter ID to delete: ");
						int i=sc.nextInt();
						int r2=stdao.deletedetails(i);
						System.out.println(r2 + " Student deleted Successfully ");
						break;
				case 5:
						System.exit(0);
						
				}
			}while(ch>0 && ch<6);
		}
		//Student s = new Student();
		//s.setId(105);
		//s.setName("Vivek Mathur");
		//int r = stdao.insert(s);
		//int r=stdao.updatedetails(s);
		//int r=stdao.deletedetails(102);
		//
		//
		//System.out.println(r + "Student deleted Successfully ");
		//Student s=stdao.selectDetails(105);
		//System.out.println(s);
		


	}
}