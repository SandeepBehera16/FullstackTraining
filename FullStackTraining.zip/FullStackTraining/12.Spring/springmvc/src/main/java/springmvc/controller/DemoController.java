
package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model)
	{		
		model.addAttribute("name","Sandeep");
		List<String> names= new ArrayList<String>();
		names.add("Hello");
		names.add("Sandeep");
		model.addAttribute("n", names);
		return "index";
	}
	@RequestMapping("/login")
	public String login()
	{
		return "request" ;
	}
	@RequestMapping(path="/request",method=RequestMethod.POST)
	public String handlerequest(@RequestParam("email") String emailid)
	{
	System.out.println(emailid);

	return "request";
	}
	@RequestMapping("/yash")
	public String yash()
	{
		return "yash";
	}
	@RequestMapping("/add")
	public ModelAndView check(HttpServletRequest request,HttpServletResponse response)
	{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("display");
	mv.addObject("result","i am Sandeep");
	return mv;
	}
	//@RequestMapping(path="/request",method=RequestMethod.POST)
	//public String handlerequest(@RequestParam("email") String emailid, Model model)
	//{
		//System.out.println(emailid);
		//Employee emp=new Employee();
		//model.addAttribute("Employee",emp);
		//return "request";
	//}
	@RequestMapping("/abc")
	public String abc()
	{
		return "abc" ;
	}
}
