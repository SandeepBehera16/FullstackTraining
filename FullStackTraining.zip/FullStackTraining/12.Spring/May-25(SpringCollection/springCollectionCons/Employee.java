package springCollectionCons;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
	private List<String> names;
	private Set<String> eid;
	private Map<Integer,String> dept;
	public Employee(List<String> names, Set<String> eid, Map<Integer, String> dept) {
		super();
		this.names = names;
		this.eid = eid;
		this.dept = dept;
	}
	public List<String> getNames() {
	      System.out.println("List Elements :"  + names);
		return names;
	}
	public void setNames(List<String> names) {
		this.names = names;
	}
	public Set<String> getEid() {
	      System.out.println("Set Elements :"  + eid);

		return eid;
	}
	public void setEid(Set<String> eid) {
		this.eid = eid;
	}
	public Map<Integer, String> getDept() {
	      System.out.println("Map Elements :"  + dept);

		return dept;
	}
	public void setDept(Map<Integer, String> dept) {
		this.dept = dept;
	}

}
