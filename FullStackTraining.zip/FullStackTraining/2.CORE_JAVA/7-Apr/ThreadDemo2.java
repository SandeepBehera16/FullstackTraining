
public class ThreadDemo2 extends Thread {
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo td=new ThreadDemo();
		td.start();
		ThreadDemo td2=new ThreadDemo();
		td2.start();
		
		
	}
}
