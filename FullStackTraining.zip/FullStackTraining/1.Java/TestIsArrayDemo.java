public class TestIsArrayDemo {
	public static void main(String[] args)
		throws ClassNotFoundException
	{
		Class c1 = Class.forName("java.lang.String");
		Object c2=new String("AlphaBitaGamma");
		Class a =c2.getClass();
		Class b=Test.class;
		System.out.println(c1.isArray());
		System.out.println(c1.isPrimitive());
		Class c3=int.class;
		System.out.println(c3.isPrimitive());		
	}
}
