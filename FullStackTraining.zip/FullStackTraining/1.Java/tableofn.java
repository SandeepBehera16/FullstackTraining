import java.util.Scanner;
class tableofn
{
  public static void main(String[] args)
  {
	int n,i=1,r;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number:");
	n=sc.nextInt();
	while(i<=10)
	{ 
	  r=i*n;
	  System.out.println(n+"*"+i+"="+r);
	  i++;
	}
}}
