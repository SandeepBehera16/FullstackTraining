
public class EnumDemoWeek
{	
	enum Week{
	MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;}	
	public static void main(String[] args)
	{
		for( Week w: Week.values())
		{System.out.println(w);}
		Week d=Week.WEDNESDAY;
		switch(d){
			case MONDAY:System.out.println("Value :"+Week.valueOf("MONDAY"));break;
			case TUESDAY:System.out.println("Value :"+Week.valueOf("TUESDAY"));break;
			case WEDNESDAY:System.out.println("Value :"+Week.valueOf("WEDNESDAY"));break;
			case THURSDAY:System.out.println("Value :"+Week.valueOf("THURSDAY"));break;
			case FRIDAY:System.out.println("Value :"+Week.valueOf("FRIDAY"));break;
			case SATURDAY:System.out.println("Value :"+Week.valueOf("SATURDAY"));break;
 			case SUNDAY:System.out.println("Value :"+Week.valueOf("SUNDAY"));break;
		}
	}
}