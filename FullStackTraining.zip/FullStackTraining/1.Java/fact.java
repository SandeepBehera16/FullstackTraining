import java.util.Scanner;
class fact
{
public static void main(String[] args)
{
	int n,fact=1,i=1;
	System.out.println("Enter a number");
	Scanner sc=new Scanner(System.in);
	n=sc.nextInt();
	while(i<=n)
	{	fact*=i;
		i++;
	}
	System.out.println("Factorial of "+n+" : "+fact);
}
}
		
