import java.util.Scanner;

public class PatternAssignmentQ3 {
	public static boolean prime(int n)
	{
		return !new String(new char[n]).matches(".?|(..+?)\\1+");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		if(prime(n))
			System.out.println("Yes, "+n+" is prime.");
		else
			System.out.println("No, "+n+" is not prime.");
	}

}
