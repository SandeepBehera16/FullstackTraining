import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//step 2:create connection
			String url="jdbc:mysql://localhost:3306/sandeep";
			String user="root";
			String pass="24may1980";
			Connection con=DriverManager.getConnection(url,user,pass);
			String q="insert into employee(empID,name) values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			//ps.setInt(1,2400);
			//ps.setString(2,"Deepak");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter empID:");
			int id=Integer.parseInt(br.readLine());
			System.out.println("Enter Name:");
			String name=br.readLine();
			ps.setInt(1,id);
			ps.setString(2, name);
			ps.executeUpdate();
			System.out.println("Inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
	}

}
