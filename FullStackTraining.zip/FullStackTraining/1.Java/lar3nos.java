import java.util.Scanner;
class lar3nos
{
public static void main(String[] args)
{
  int a,b,c;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter 3 numbers:");
  a=sc.nextInt();
  b=sc.nextInt();
  c=sc.nextInt();
  if(a>b && a>c)
        System.out.println(a+" is Largest.");
  else if(b>c && b>a)
        System.out.println(b+" is Largest.");
  else
	System.out.println(c+" is Largest.");
}
}
