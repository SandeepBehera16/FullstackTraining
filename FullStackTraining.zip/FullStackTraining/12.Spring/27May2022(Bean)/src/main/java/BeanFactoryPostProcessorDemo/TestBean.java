package BeanFactoryPostProcessorDemo;

public class TestBean {
	public TestBean(){
		System.out.println("Object of TestBean is created.");
	}
} 