import java.util.Iterator;
import java.util.TreeSet;
public class AssignmentQ7
{
	public static void main(String[] args){
	TreeSet<String> t=new TreeSet<>();
	t.add("Bhim");
	t.add("Ram");
	t.add("Ranjan");
	t.add("Rahim");
	Iterator<String> i=t.iterator();
	String a="Bhim";
	boolean r=false;
	while(i.hasNext())
	{
		if(i.next().equals(a))
		{
			r=true;
			break;
		}
	}
	if(r) System.out.println(a+" exists");
	else  System.out.println(a+" doesn't exists");
	}
}	