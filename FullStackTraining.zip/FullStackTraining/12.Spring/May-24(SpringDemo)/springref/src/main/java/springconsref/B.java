package springconsref;

public class B {
@Override
	public String toString() {
		return "B [y=" + y + "]";
	}

private int y;

public B(int y) {
	super();
	this.y = y;
}
}
