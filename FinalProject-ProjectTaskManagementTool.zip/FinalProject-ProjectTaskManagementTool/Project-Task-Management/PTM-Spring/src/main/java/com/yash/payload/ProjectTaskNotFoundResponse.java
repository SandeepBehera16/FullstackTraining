package com.yash.payload;

public class ProjectTaskNotFoundResponse {

    private String ProjectTaskNotFound;

    public ProjectTaskNotFoundResponse(String ProjectTaskNotFound) {
        ProjectTaskNotFound = ProjectTaskNotFound;
    }

    public String getProjectTaskNotFound() {
        return ProjectTaskNotFound;
    }

    public void setProjectTaskNotFound(String projectTaskNotFound) {
        ProjectTaskNotFound = projectTaskNotFound;
    }

}
