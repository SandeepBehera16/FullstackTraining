class ExpMsg
{
	public static void main(String[] args)
	{
	try
	{
	   int a=100,b=0,c;
	   System.out.println(a/b);
 	}
 	catch(ArithmeticException e)
	{
 	  e.printStackTrace();
 	  //System.out.println(e);
   	  //System.out.println(e.getMessage);
	}
	finally
	{
	System.out.println("Done");
	}
	}
}