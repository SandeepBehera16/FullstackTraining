import java.util.HashSet;
import java.util.Iterator;

class Employee
{
	private String eName;
	public Employee(String eName)
	{
		this.eName=eName;
	}
	public String toString()
	{
	return "Employee Name: "+eName;
	}
}
class AssignmentQ6
{
	public static void main(String[] args)
	{
	Employee e1=new Employee("Raj");
	Employee e2=new Employee("Rajesh");
	Employee e3=new Employee("Rajiv");
	Employee e4=new Employee("Rajkishor");
	HashSet<Employee> v=new HashSet<>();
	v.add(e1);
	v.add(e2);
	v.add(e3);
	v.add(e4);
	Iterator<Employee> i= v.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	}
}	