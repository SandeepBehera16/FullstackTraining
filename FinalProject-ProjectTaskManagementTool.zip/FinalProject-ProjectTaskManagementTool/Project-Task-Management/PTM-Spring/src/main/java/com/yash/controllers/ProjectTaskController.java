package com.yash.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.entities.ProjectTask;
import com.yash.services.MapValidationErrorService;
import com.yash.services.ProjectTaskService;

@RestController
@RequestMapping("/api/task")
@CrossOrigin(origins = " * ", allowedHeaders = " * ")
public class ProjectTaskController {

    @Autowired
    private ProjectTaskService projectTaskService;

    @Autowired
    private MapValidationErrorService mapValidationErrorService;

    @GetMapping("/all/{projectIdentifier}")
    public Iterable<ProjectTask> getAllProjectTasks(@PathVariable String projectIdentifier) {
        return projectTaskService.findAllTasks(projectIdentifier);
    }

    @GetMapping("/{projectIdentifier}/{projectTaskIdentifier}")
    public ResponseEntity<?> getProjectTaskById(@PathVariable String projectIdentifier,
            @PathVariable String projectTaskIdentifier) {
        ProjectTask projectTask = projectTaskService.findProjectTaskByIdentifier(
                projectIdentifier, projectTaskIdentifier);
        return new ResponseEntity<ProjectTask>(projectTask, HttpStatus.OK);
    }

    @PostMapping("/{projectIdentifier}")
    public ResponseEntity<?> createProjectTask(@Valid @RequestBody ProjectTask projectTask, BindingResult result,
            @PathVariable String projectIdentifier) {
        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if (errorMap != null) {
            return errorMap;
        }
        ProjectTask newProjectTask = projectTaskService.saveOrUpdateTask(projectTask, projectIdentifier);
        return new ResponseEntity<ProjectTask>(newProjectTask, HttpStatus.CREATED);
    }

    @DeleteMapping("/{projectId}/{taskId}")
    public ResponseEntity<?> deleteProjectTask(@PathVariable String projectId, @PathVariable String taskId) {
        projectTaskService.deleteProjectTaskByIdentifier(projectId, taskId);
        return new ResponseEntity<String>("Task with ID " + taskId + " deleted", HttpStatus.OK);
    }

}
