import com.automobile.Honda;
import com.automobile.twowheeler.Hero;

public class AssignQ5 {

	public static void main(String[] args) {
		Hero hero = new Hero("Yamha MT15", "OD16H1294", "Sandeep Behera", 85);
		hero.getModelName();
		hero.getOwnerName();
		hero.getRegistrationNumber();
		hero.getSpeed();
		hero.radio();
		
		System.out.println();
		
		Honda honda = new Honda("Yamaha R15", "MH18G7797", "Prodoshi Das", 110);
		honda.getModelName();
		honda.getOwnerName();
		honda.getRegistrationNumber();
		honda.getSpeed();
		honda.cdplayer();

	}

}