import java.util.Vector;
import java.util.Iterator;

class Employee
{
	private int eId;
	private String eName;
	private String eDesignation;
	public Employee(int eId,String eName,String eDesignation)
	{
		super();
		this.eId=eId;
		this.eName=eName;
		this.eDesignation=eDesignation;
	}
	public int getId(){
		return eId;
	}
	@Override
	public String toString()
	{
	return "Employee[id: "+eId+", Name: "+eName+", Designation: "+eDesignation+"]";
	}
}
class AssignmentQ4
{
	public static void main(String[] args)
	{
	/*Employee e1=new Employee(10112,"Raj","AT");
	Employee e2=new Employee(10123,"Rajesh","AT");
	Employee e3=new Employee(10134,"Rajiv","AT");
	Employee e4=new Employee(10145,"Rajkishor","AT");*/
	Vector<Employee> v=new Vector<Employee>();
	v.add(new Employee(10112,"Raj","AT"));
	/*v.add(e2);
	v.add(e3);
	v.add(e4);*/
	Iterator<Employee> i= v.iterator<Employee>();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	}
}	