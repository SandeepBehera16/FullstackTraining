import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternAssignmentQ1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str;
		System.out.println("Enter a String with Integers:");
		str=sc.nextLine();
		ArrayList<String> s=Extract(str);
		System.out.println("All numbers from the string:"+s);
	}
	public static ArrayList<String> Extract(String str)
	{
		ArrayList<String> s=new ArrayList<String>();
		Pattern p=Pattern.compile("\\d+");
		Matcher m=p.matcher(str);
		while(m.find())
		{
			s.add(m.group());
		}
		return s;
	}

}
