
public class ThreadDeamonDemo extends Thread {
	public void run()
	{
		System.out.println("In run method");
		if(Thread.currentThread().isDaemon())
			System.out.println("I am in Deamon thread");
		else
			System.out.println("I am in non Deamon Thread");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In main thread");
		ThreadDeamonDemo td=new ThreadDeamonDemo();
		td.setDaemon(true);
		td.start();
	}

}
