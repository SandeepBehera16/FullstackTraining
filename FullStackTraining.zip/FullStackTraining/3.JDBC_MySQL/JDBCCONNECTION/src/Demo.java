import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//step 2:create connection
			String url="jdbc:mysql://localhost:3306/sandeep";
			String user="root";
			String pass="24may1980";
			Connection con=DriverManager.getConnection(url,user,pass);
			String q="UPDATE employee SET name='Deepika' WHERE empID=1015099";
			PreparedStatement ps=con.prepareStatement(q);
			ps.executeUpdate(q);
			System.out.println("Inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
	}

}
