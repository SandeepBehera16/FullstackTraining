
public class ThreadSleepDeno extends Thread {
	public void run()
	{
		for(int i=1;i<=3;i++)
		{
			try {
				//Thread.sleep(1000);
				System.out.println(Thread.currentThread().getName());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadSleepDeno ts=new ThreadSleepDeno();
		ts.setName("Yahs Technologies");
		ts.setPriority(10);
		ts.start();
		ThreadSleepDeno ts1=new ThreadSleepDeno();
		ts1.setName("Sandeep");
		ts1.setPriority(1);
		ts1.start();
	}

}
