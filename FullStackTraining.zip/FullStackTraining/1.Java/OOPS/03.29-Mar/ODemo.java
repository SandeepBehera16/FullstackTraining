class Outer{
	static class Inner{
		void show(){
			System.out.println("Outer Show");
		}
	}
}
public class ODemo{
	public static void main(String[] args){
		Outer.Inner o=new Outer.Inner();
		o.show();
	}
}