function printEvenTable()
{
	var i=1;
	for(i=1;i<=10;i++)
	{
		if(i%2==0)
		{
			console.log(i);
			for(let j = 1; j <= 10; j++) {
					result = j * i;
					console.log(`${i} * ${j} = ${result}`);
			}
		}
	}	
};

printEvenTable();