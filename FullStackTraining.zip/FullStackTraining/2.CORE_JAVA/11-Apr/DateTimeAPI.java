import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.*;
public class DateTimeAPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate dt=LocalDate.now();
		System.out.println("Date:"+dt);
		LocalTime ti=LocalTime.now();
		System.out.println("Time:"+ti);	
		LocalDateTime dtm=LocalDateTime.now();
		System.out.println("Current dt time:"+dtm);
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formatedDateTime= current.format(format);
		System.out.println(formatedDateTime);
		Month m=current.getMonth();
	}

}
