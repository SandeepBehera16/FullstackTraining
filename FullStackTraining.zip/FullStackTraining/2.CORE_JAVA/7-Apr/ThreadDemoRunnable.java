
public class ThreadDemoRunnable implements Runnable {
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t=new Thread(new ThreadDemoRunnable());
		t.start();

	}

}
