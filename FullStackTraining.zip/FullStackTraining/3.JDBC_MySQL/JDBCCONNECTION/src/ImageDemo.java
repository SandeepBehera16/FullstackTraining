import java.awt.Image;
import java.awt.Toolkit;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ImageDemo extends JFrame {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/sandeep";
			String user="root";
			String pass="24may1980";
			Connection con=DriverManager.getConnection(url,user,pass);
			String q="create table student(sroll int(10),sname varchar(20),slogo longblob)";
			PreparedStatement ps1=con.prepareStatement(q);
			ps1.execute();
			String q1="insert into student(sroll,sname,slogo) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(q1);
			ps.setInt(1,120);
			ps.setString(2,"Harmayoni");
			FileInputStream fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\g.jpg");
			ps.setBinaryStream(3, fin);
			ps.execute();
			
			ps.setInt(1,210);
			ps.setString(2,"Harry");
			fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\r.png");
			ps.setBinaryStream(3, fin);
			ps.execute();
			
			ps.setInt(1,501);
			ps.setString(2,"Draco");
			fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\s.png");
			ps.setBinaryStream(3, fin);
			ps.execute();
			System.out.println("Data Inserted\n");
			ResultSet set1=ps.executeQuery("select * from student");
			JLabel photoL = null;
			while(set1.next())
			{
				System.out.println("Roll No.:"+set1.getInt("sroll"));
				System.out.println("Name:"+set1.getString("sname"));
				System.out.println("House:"+set1.getBlob("slogo")+"\n");
				byte bt[]=(set1.getBlob(3)).getBytes(1,(int)(set1.getBlob(3)).length());
				Image img=Toolkit.getDefaultToolkit().createImage(bt);
				photoL.setIcon(new ImageIcon(img));
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
}
