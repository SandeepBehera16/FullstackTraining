var nolist=[3,5,7,9];
function * gen(arrno)
{
  let i=0;
  while(i<arrno.length)
  {
	  console.log("generator is called"+i+"times");
    yield arrno[i];
    i++;
  }
}
var y = gen(nolist);
console.log(y.next().value);
//console.log(y.next().value);
//console.log(y.next().value);
//console.log(y.next().value);