package AnnotationsInAutowire;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("AnnotationsInAutowire/applicationcontext.xml");
		 @SuppressWarnings("deprecation")
		//BeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("AnnotationsInAutowire/applicationcontext.xml"));
		Employee e = context.getBean("emp", Employee.class);

		//Employee e = (Employee) beanFactory.getBean("emp");
		System.out.println(e);

	}

}
