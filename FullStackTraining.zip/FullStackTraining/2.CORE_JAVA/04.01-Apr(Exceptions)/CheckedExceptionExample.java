import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ClassNotFoundException;
import java.io.FileNotFoundException;
class CheckedExceptionExample
{
	public static void main(String[] args)throws IOException,ClassNotFoundException,FileNotFoundException
	{
		FileInputStream f=new FileInputStream("d:/abc.txt");
		FileOutputStream o=new FileOutputStream("d:/xyz.txt");
		int c;
		try{
		while((c=f.read())!=-1)
		{
			o.write(c);
			System.out.println((char)c);
		}
		}
		catch(IOException|ClassNotFoundException|FileNotFoundException e)
		{
			e.printStackTrace();
		}	
		finally{
		f.close();
		o.close();
		}
	}
}	