class Outer
{	static int m=10;
	void disp()
	{
		System.out.println("Outside of inner class");
	}
	static class Inner
	{
		void show()
		{	
			System.out.println("Outer Show"+m);
		}
	}
}
public class ODemoNonStatic
{
	public static void main(String[] args)
	{
		Outer.Inner ob=new Outer.Inner();
		//Outer.Inner oi = ob.new Inner(); I
		ob.show();
		//ob.disp();
	}
}