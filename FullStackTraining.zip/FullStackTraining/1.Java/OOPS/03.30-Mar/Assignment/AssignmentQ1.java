import java.io.FileInputStream;
import java.io.*;
import java.io.IOException;
class AssignmentQ1
{
	public static void main(String[] args) throws IOException
	{
        File file = new File("d:/yash.txt");
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        BufferedReader f1 = new BufferedReader(inputStreamReader);
	String line;
        int wordCount = 0;
        int characterCount = 0;
        int whiteSpaceCount = 0;
        int sentenceCount = 0;
	while((line=f1.readLine())!=null)
        {
	
                characterCount += line.length();
		String words[] = line.split("\\s+");
                wordCount += words.length;
                whiteSpaceCount += wordCount - 1;
                String sentence[] = line.split("[!?.:]+");
                sentenceCount += sentence.length;
	}
        System.out.println("Total number of Lines= "+ sentenceCount);
        System.out.println("Total number of characters = "+ characterCount);
       	System.out.println("Total number of spaces = "+ whiteSpaceCount);
    f1.close();
	}
}
                       
