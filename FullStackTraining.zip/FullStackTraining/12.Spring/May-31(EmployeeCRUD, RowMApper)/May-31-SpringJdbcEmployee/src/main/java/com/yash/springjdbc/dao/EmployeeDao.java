package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.Employee;

public interface EmployeeDao {

	public int insert(Employee emp);
	public int updatedetails(Employee emp);
	public int deletedetails(int stuid);
}