import java.util.Scanner;
class evenodd
{
public static void main(String[] args)
{
  int n;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter a number:");
  n=sc.nextInt();
  if(n%2==0)
        System.out.println(n+" is Even.");
  else
        System.out.println(n+" is Odd.");
}
}
