import java.util.Scanner;
class factrec
{
static int fact(int n){    
  if (n == 0)    
    return 1;    
  else    
    return(n * fact(n-1));    
 }    
public static void main(String[] args)
{
        int n,f=1,i=1;
        System.out.println("Enter a number");
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        f=fact(n);
        System.out.println("Factorial of "+n+" : "+f);
}
}
