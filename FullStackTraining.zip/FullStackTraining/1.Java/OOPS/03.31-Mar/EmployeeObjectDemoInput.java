import java.io.*;
class Employee implements Serializable
{
int empId;
String empName;
Employee(int empId,String empName)
{this.empId=empId;
this.empName=empName;
}
public String toString()
{
	return empId+" "+empName;
}
}
class EmployeeObjectDemoInput
{
public static void main(String[] args) throws Exception
{
	 
	File f=new File("d:/xyz.txt");
	ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
	//ois.writeObject(e);
	Employee e=(Employee)ois.readObject();	
	System.out.println(e);
	ois.close();
}
}