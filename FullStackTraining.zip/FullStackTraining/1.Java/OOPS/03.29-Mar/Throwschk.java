import java.io.IOException;
class ThrowsD
{
void show() throws IOException
{
throw new IOException("device error");
}
}
class Throwschk
{ public static void main(String[] args)
{ ThrowsD t=new ThrowsD();
   try{
	t.show();}
   catch(IOException e)
	{e.printStackTrace();}
    System.out.println("Normal Termination");
}
}