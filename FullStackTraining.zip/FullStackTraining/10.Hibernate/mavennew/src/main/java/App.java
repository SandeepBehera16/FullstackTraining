import org.hibernate.*;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;    
    
public class App {
	public static void main(String[] args) {    
	      
	    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	      
	    Transaction t=session.beginTransaction();   
	      
	    Employee e1=new Employee();    
	    e1.setName("Deepak Burma");    
	    e1.setEmail("deepak@gmail.com");    
	    Address address1=new Address();    
	    address1.setAddressLine1("13/21,Soubhagya nagar");    
	    address1.setCity("Bhubaneswar");    
	    address1.setState("Odisha");    
	    address1.setCountry("India");    
	    address1.setPincode(751008);    
	        
	    e1.setAddress(address1);    
	    address1.setEmployee(e1);    
	        
	    session.persist(e1);    
	    t.commit();    
	        
	    session.close();    
	    System.out.println("success");    
	}    
}
