import java.lang.ArithmeticException;
import java.lang.NumberFormatException;
import java.lang.ClassCastException;
import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.NullPointerException;
import java.util.Scanner;
class UncheckExceptionExample
{
	public static void main(String[] args) throws ArithmeticException,NumberFormatException,ArrayIndexOutOfBoundsException,NullPointerException,ClassCastException
	{
			int ar[]=new int[5];
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter 5 Elements in Array");
			try{
				for(int i=0;i<5;i++)
					ar[i]=sc.nextInt();
				System.out.println("Enter a number you want(1-5)");
				int ch=sc.nextInt();
				switch(ch){
				case 1:ar[0]=ar[0]/0;break;
				case 2:int m=ar[11];break;
				case 3:int mr=Integer.parseInt("A101");break;
				case 4:for(int i=0;i<5;i++)
							System.out.println(ar[i]+" ");
						break;
				}
			}	
			catch(ArithmeticException|NullPointerException|NumberFormatException|ArrayIndexOutOfBoundsException|ClassCastException e)
			{ e.printStackTrace();
			}
	}
}	