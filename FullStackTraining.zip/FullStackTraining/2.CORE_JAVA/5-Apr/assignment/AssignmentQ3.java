import java.util.ArrayList;
import java.util.Vector;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class AssignmentQ3 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("January");
		al.add("February");
		al.add("March");
		al.add("April");
		al.add("May");
		al.add("June");
		al.add("July");
		al.add("August");
		al.add("Sepetember");
		al.add("October");
		al.add("November");
		al.add("December");
		Vector<String> v=new Vector<String>(al);
		Iterator i=v.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}	