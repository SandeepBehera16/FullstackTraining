package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.springjdbc.dao.EmployeeDao;
import com.yash.springjdbc.entities.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		EmployeeDao stdao = context.getBean("EmployeeDao", EmployeeDao.class);

		Employee s = new Employee();
		s.setId(103);
		s.setName("Surya Verma");
		//s.setEmailid("deepak.verma@yash.com");
		//s.setDob("21/02/1979");
		//s.setContactno("4566543218");
		//s.setSalary("50000");
		//int r = stdao.insert(s);
		//int r=stdao.updatedetails(s);
		int r=stdao.deletedetails(102);
		//System.out.println(r + "Employee added Successfully ");
		//System.out.println(r + "Employee details Updated Successfully ");
		System.out.println(r + "Employee deleted Successfully ");


	}
}