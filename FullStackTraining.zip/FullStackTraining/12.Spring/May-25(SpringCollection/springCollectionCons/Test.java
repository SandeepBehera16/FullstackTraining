package springCollectionCons;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Spring using Collection");
		ApplicationContext context=new ClassPathXmlApplicationContext("springCollectionCons/applicationcontext.xml");
	      Employee jc=(Employee)context.getBean("emp");
		jc.getNames();
		jc.getEid();
		jc.getDept();
		
	}

}
