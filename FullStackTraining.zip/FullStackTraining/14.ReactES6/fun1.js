function show()
{
  console.log("show function called");
 }
 show();
 
var x=function(a,b) 
{
	console.log(a+b);	
} 
x(12,22);