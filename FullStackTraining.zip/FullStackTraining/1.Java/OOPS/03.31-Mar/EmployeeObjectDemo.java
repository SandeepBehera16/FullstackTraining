import java.io.*;
class Employee implements Serializable
{
int empId;
String empName;
Employee(int empId,String empName)
{this.empId=empId;
this.empName=empName;
}
public String toString()
{
	return empId+" "+empName;
}
}
class EmployeeObjectDemo
{
public static void main(String[] args) throws Exception
{
	 Employee e=new Employee(22,"Sandeep");	
	System.out.println(e);
	File f=new File("d:/xyz.txt");
	ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
	oos.writeObject(e);
	oos.close();
}
}