import java.util.Scanner;
class lar2nos
{
public static void main(String[] args)
{
  int m,n;
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter 2 numbers:");
  m=sc.nextInt();
  n=sc.nextInt();
  if(m>n)
	System.out.println(m+" is Larger.");
  else
	System.out.println(n+" is Larger.");
}
}
