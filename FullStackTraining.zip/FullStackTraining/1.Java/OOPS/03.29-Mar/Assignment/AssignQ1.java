abstract class GeneralBank
{
	public abstract double getSavingInterestRate();
	public abstract double getFixedInterestRate();
}
class ICICIBank extends GeneralBank 
{
	public double getSavingInterestRate()
	{
		return 4.0;
	}
	public double getFixedInterestRate() 
	{
		return 8.5;
	}
}
class SBIBank extends GeneralBank 
{
	public double getSavingInterestRate()
	{
		return 4.0;
	}
	public double getFixedInterestRate() 
	{
		return 7.0;
	}

}
public class AssignQ1
{
	public static void main(String[] args)
	{	ICICIBank iciciBank = new ICICIBank();
		SBIBank sbiBank = new SBIBank();

		System.out.println(iciciBank.getSavingInterestRate());
		System.out.println(iciciBank.getFixedInterestRate());
		System.out.println(sbiBank.getSavingInterestRate());
		System.out.println(sbiBank.getFixedInterestRate());
		
		GeneralBank obj1 = new ICICIBank();
		GeneralBank obj2 = new SBIBank();
		
		System.out.println(obj1.getSavingInterestRate());
		System.out.println(obj1.getFixedInterestRate());
		System.out.println(obj2.getSavingInterestRate());
		System.out.println(obj2.getFixedInterestRate());
	}
}