import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
class BufferedOutputDemo
{
	public static void main(String[] args)
	{
		try
		{	
		FileInputStream fin=new FileInputStream("d:/xyz.txt");
		BufferedInputStream binput=new BufferedInputStream(fin);
		FileOutputStream fo=new FileOutputStream("d:/pqr.txt");
		BufferedOutputStream boutput=new BufferedOutputStream(fo); 
		int i;
		while((i=binput.read())!=-1)
		{System.out.print((char)i);
		 boutput.write(i);
		}
		binput.close();
		fin.close();
		boutput.close();
		fo.close();
		}
		catch(Exception e)
		{e.printStackTrace();
		}
	}
}