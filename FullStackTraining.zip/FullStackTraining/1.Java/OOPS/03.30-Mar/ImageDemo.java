import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ImageDemo {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/sandeep";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			String q="create table student(roll int(10),name varchar(20),logo longblob)";
			PreparedStatement ps1=con.prepareStatement(q);
			ps1.execute();
			String q1="insert into student(roll,name,logo) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(q1);
			ps.setInt(1,120);
			ps.setString(2,"Harmayoni");
			FileInputStream fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\g.jpg");
			ps.setBinaryStream(3, fin);
			ps.execute();
			
			ps.setInt(1,210);
			ps.setString(2,"Harry");
			fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\r.png");
			ps.setBinaryStream(3, fin);
			ps.execute();
			
			ps.setInt(1,501);
			ps.setString(2,"Draco");
			fin = new FileInputStream("C:\\Users\\Lenovo\\Desktop\\s.png");
			ps.setBinaryStream(3, fin);
			ps.execute();
			System.out.println("Data Inserted");
			String q2="select * from student";
			Statement st=con.createStatement();
			ResultSet set1=st.executeQuery(q2);
			while(set1.next())
			{
				System.out.println("Roll No.:"+set1.getInt("roll"));
				System.out.println("Name:"+set1.getString("name"));
				System.out.println("House:"+set1.getBlob("logo")+"\n");
			}	
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
}
