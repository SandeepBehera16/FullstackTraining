public class EnumDemoSeason
{
	enum Season{
	SUMMER(1),WINTER(2),RAINY(3),AUTUM(4),SPRING(5),FALL(6);
	 int val;
	Season(int val)
	{this.val=val;}}
	public static void main(String[] args)
	{for(Season s:Season.values())
		{System.out.println(s+" "+s.val);
		}
	}
}