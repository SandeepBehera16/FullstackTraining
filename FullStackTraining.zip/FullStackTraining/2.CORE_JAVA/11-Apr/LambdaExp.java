interface Drawable
{
	public void draw();
}
public class LambdaExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int w=10;
		Drawable d2=()->{
			System.out.println("Drawing-"+w);
		};
		d2.draw();
	}

}
