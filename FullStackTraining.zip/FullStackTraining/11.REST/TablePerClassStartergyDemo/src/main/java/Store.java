
import org.hibernate.boot.Metadata;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder; 

public class Store {
	
	public static void main(String[] args) {    
	      
	    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	    
	    Transaction t=session.beginTransaction();    
	        
	    Emp e1=new Emp();    
	    e1.setName("Sandeep Behera");    
	        
	    P_Emp e2=new P_Emp();    
	    e2.setName("Sudhanshu behera");    
	    e2.setSalary(50000);    
	    e2.setBonus(5);    
	        
	    C_Emp e3=new C_Emp();    
	    e3.setName("Vivek Suman");    
	    e3.setPay_per_hour(1000);    
	    e3.setContract_duration("15 hours");    
	        
	    session.persist(e1);    
	    session.persist(e2);    
	    session.persist(e3);    
	        
	    t.commit();    
	    session.close();    
	    System.out.println("success");    
	}    
	}    


