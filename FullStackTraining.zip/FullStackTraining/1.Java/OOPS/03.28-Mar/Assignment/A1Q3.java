import java.util.Scanner;
public class A1Q3 {
	public static void main(String[] args)
	{
		int n,m;  
	Scanner sc=new Scanner(System.in);  
	System.out.print("Enter the number of elements:");  
  
	n=sc.nextInt();  

	int[] ar = new int[n];  
	System.out.println("Enter the elements of the array: ");  
	for(int i=0; i<n; i++)  
	{  

	ar[i]=sc.nextInt();  
	}
	System.out.println("Enter the index:");
	
		try {  m=sc.nextInt();
			System.out.print(ar[m]);
			}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch(NumberFormatException e)
		{
		System.out.println(e);
		}
	}
}
