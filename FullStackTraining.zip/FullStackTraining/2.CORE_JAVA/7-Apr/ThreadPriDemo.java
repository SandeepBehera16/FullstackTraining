
public class ThreadPriDemo extends Thread {
	public void run()
	{
		System.out.println("In run Method");
		System.out.println(Thread.currentThread().getPriority());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(MIN_PRIORITY);
		ThreadPriDemo tp=new ThreadPriDemo();
		tp.start();
	}

}
