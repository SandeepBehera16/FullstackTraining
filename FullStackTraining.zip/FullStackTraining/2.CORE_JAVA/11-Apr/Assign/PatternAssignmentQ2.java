import java.util.Arrays;
import java.util.Scanner;
public class PatternAssignmentQ2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str="Line1\r\n\rLine2\r\nLine3";
		String[] s =str.split("\\r?\\n");
		for(String l:s)
			System.out.println(l);
	}

}
