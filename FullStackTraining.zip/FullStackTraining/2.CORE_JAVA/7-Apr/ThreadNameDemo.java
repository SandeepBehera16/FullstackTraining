
public class ThreadNameDemo extends Thread {
	public void run()
	{
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
		ThreadNameDemo t1=new ThreadNameDemo();
		System.out.println(t1.isAlive());
		t1.setName("Thread");
		t1.start();
		System.out.println(t1.isAlive());
		System.out.println(Thread.currentThread().isAlive());
		
	}

}
