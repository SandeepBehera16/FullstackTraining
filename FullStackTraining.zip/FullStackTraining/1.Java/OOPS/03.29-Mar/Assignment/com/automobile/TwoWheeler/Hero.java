package com.automobile.twowheeler;
import com.automobile.Vehicle;
pubpublic class Hero extends Vehicle {

	public void getModelName() {
		return "Hero";
	}

	
	public void getRegistrationNumber() {
		return "4533";	
	}

	
	public void getOwnerName() {
		return Sandeep;
	}

	public int getSpeed() {
		return 100;
	}
	
	public void radio() {
		System.out.println("Radio");
	}
	
}