function area()
{
  let cir = 3.14*5*5;
  let rect =10*12;
  let sq    = 15*15;
  return [cir,rect,sq];
}
var [cir1,rect1,sq1] =area();
console.log("area of circle"+cir1);
console.log("area of rectangle"+rect1);
console.log("area of square"+sq1);