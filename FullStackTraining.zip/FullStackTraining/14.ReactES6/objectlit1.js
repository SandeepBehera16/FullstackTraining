var name ="sunil";
var dob="23/2/2000";
var sal=23456;
/*
var e ={name,dob,sal};
console.log( e);

var fn =function(){
	console.log("function 1");	
}
var d={name,dob,sal,fn};
d.fn(); */

var showDetail=function()
{
	console.log("empname "+this.name+ "__dob:- "+this.dob+"__ salary"+this.sal);	
}
var o2 ={name,dob,sal,showDetail};
o2.showDetail();
var emp2 = {
	name:"ajay kumar", "salary":34555,"dob":"23/3/2001",printdetail(){
		console.log(this.name);
		console.log(this.dob);
		console.log(this.salary);
	}
	
};
emp2.printdetail();