import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
class ByteArrayInputDemo
{
public static void main(String[] args) throws Exception
{
 byte[] buf = { 35, 36, 37, 38 }; 
FileOutputStream ot=new FileOutputStream("d:/def.txt");
ByteArrayInputStream byt = new ByteArrayInputStream(buf);  
int i;
while((i=byt.read())!=-1)
{
ot.write(i);
System.out.print((char)i);
}
byt.close();
ot.close();


}
}